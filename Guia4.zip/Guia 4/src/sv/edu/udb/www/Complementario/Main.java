package sv.edu.udb.www.Complementario;

import static sv.edu.udb.www.Complementario.Menu.menuPrincipal;

public class Main {
    public static void main(String[] args) {
        menuPrincipal();
    }
}
