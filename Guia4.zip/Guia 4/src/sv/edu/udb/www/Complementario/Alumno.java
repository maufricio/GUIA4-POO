package sv.edu.udb.www.Complementario;

import sv.edu.udb.www.util.Conexion;

import javax.swing.*;
import java.sql.*;

import static sv.edu.udb.www.Complementario.Validaciones.validaNumero;



public class Alumno {
    private static int cod_alumno;
    private static String nombre;
    private static String apellido;
    private static int edad;
    private static String direccion;

    private Connection conexion;
    private ResultSet rs;
    private Statement s;
    public Alumno(){

    }

    public Alumno(int cod_alumno, String nombre, String apellido, int edad, String direccion) {
        this.cod_alumno = cod_alumno;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.direccion = direccion;
    }

    public int getCod_alumno() {
        return cod_alumno;
    }

    public void setCod_alumno(int cod_alumno) {
        this.cod_alumno = cod_alumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    //METODO PARA MOSTRAR ALUMNOS
    public static void mostrarAlumnos() throws SQLException {
        Conexion con = new Conexion();
        String sql = "SELECT * from alumno";
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();
        while (rs.next()) {
            JOptionPane.showMessageDialog(null, "Codigo de Alumno: " + rs.getString("Cod_alumno") +
                    "\nNombre: " + rs.getString("Nombre") +
                    "\nApellido: " + rs.getString("Apellido") +
                    "\nEdad: " + rs.getString("Edad") +
                    "\nDireccion: " + rs.getString("Direccion"));
        };
    }

    //METODO PARA BUSCAR UN ALUMNO
    public static void buscarAlumno() throws SQLException {
        //Validacion del codigo de barra
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno");
        Long codigov = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codigov >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno");
                codigov = Long.parseLong(codigo);
            }
        } while (true);

        Conexion con = new Conexion();
        String sql = "SELECT * FROM alumno WHERE Cod_alumno = " + codigo;
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(null, "El alumno no se encuentra en nuestra base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "ALUMNO ENCONTRADO\n" +
                    "\nCodigo de Alumno: " + rs.getString("Cod_alumno") +
                    "\nNombre: " + rs.getString("Nombre") +
                    "\nApellido: " + rs.getString("Apellido") +
                    "\nEdad: " + rs.getString("Edad") +
                    "\nDirección: $" + rs.getString("Direccion"));
        }
        con.cerrarConexion();
    }

    //METODO PARA AGREGAR ALUMNOS
    public static void agregarALumnos() throws SQLException{
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno. MAXIMO 10 DIGITOS");
        Long codv = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codv >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno. MAXIMO 10 DIGITOS");
                codv = Long.parseLong(codigo);
            }
        } while (true);
        cod_alumno = Integer.parseInt(codigo);
        nombre = (JOptionPane.showInputDialog("Ingrese el nombre del alumno"));
        apellido = (JOptionPane.showInputDialog("Imgrese el apellido del alumno"));
        edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad"));
        direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        Conexion con = new Conexion();
        String sql = "insert into alumno values(?,?,?,?,?)";
        PreparedStatement ps = con.getConexion().prepareStatement(sql);
        ps.setInt(1, cod_alumno);
        ps.setString(2, nombre);
        ps.setString(3, apellido);
        ps.setInt(4, edad);
        ps.setString(5, direccion);
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Se han insertado los datos");
    }

    //METODO PARA BUSCAR UN ALUMNO
    public static void alumnoSeleccionado(Integer codigo_alumno) throws SQLException {
        Conexion con = new Conexion();
        String sql = "SELECT * FROM alumno WHERE Cod_alumno = " + codigo_alumno;
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(null, "El alumno no se encuentra en nuestra base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "AÑADIRA MATERIA AL SIGUIENTE ALUMNO\n" +
                    "\nCodigo de Alumno: " + rs.getString("Cod_alumno") +
                    "\nNombre: " + rs.getString("Nombre") +
                    "\nApellido: " + rs.getString("Apellido") +
                    "\nEdad: " + rs.getString("Edad") +
                    "\nDirección: $" + rs.getString("Direccion"));
        }
        con.cerrarConexion();
    }
}
