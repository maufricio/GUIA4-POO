package sv.edu.udb.www.Complementario;

import javax.swing.*;

import static sv.edu.udb.www.Complementario.Alumno.*;
import static sv.edu.udb.www.Complementario.Alumno_Materia.agregarMateriaAlumno;
import static sv.edu.udb.www.Complementario.Alumno_Materia.listarMateriasAlumno;
import static sv.edu.udb.www.Complementario.Materia.*;

public class Menu {

    public static void menuPrincipal() {
        //Variables de menu
        String opt = "";
        String mensaje = "¿Que desea realizar?\n" +
                "a. Gestionar Alumno\n" +
                "b. Gestionar Materias\n" +
                "c. Mostrar materias inscritas de un alumno\n" +
                "d. Agregar materia a alumno\n"+
                "e. Salir";
        boolean salir = false;

        //Menu
        while (!salir) {
            try {
                opt = JOptionPane.showInputDialog(mensaje);
                switch (opt) {
                    case "a":
                        menuAlumno();
                        break;
                    case "b":
                        menuMateria();
                        break;
                    case "c":
                        listarMateriasAlumno();
                        break;
                    case "d":
                        agregarMateriaAlumno();
                        break;
                    case "e":
                        salir = true;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Valor ingresado invalido\nSeleecione una opción del menu", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Hubo un problema con la obtencion de datos. Por favor intente de nuevo", "ERROR", JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    //MENU PARA ALUMNO
    public static void menuAlumno() {
        //Variables de menu
        String opt = "";
        String mensaje = "¿Que desea realizar?\n" +
                "a. Mostrar Alumnos\n" +
                "b. Buscar Alumno\n" +
                "c. Agregar Alumno\n" +
                "d. Salir";
        boolean salir = false;

        //Menu
        while (!salir) {
            try {
                opt = JOptionPane.showInputDialog(mensaje);
                switch (opt) {
                    case "a":
                        mostrarAlumnos();
                        break;
                    case "b":
                        buscarAlumno();
                        break;
                    case "c":
                        agregarALumnos();
                        break;
                    case "d":
                        salir = true;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Valor ingresado invalido\nSeleecione una opción del menu", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Hubo un problema con la obtencion de datos. Por favor intente de nuevo", "ERROR", JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }

    //MENU PARA MATERIA
    public static void menuMateria() {
        //Variables de menu
        String opt = "";
        String mensaje = "¿Que desea realizar?\n" +
                "a. Mostrar Materias\n" +
                "b. Buscar Materia\n" +
                "c. Agregar Materia\n" +
                "d. Salir";
        boolean salir = false;

        //Menu
        while (!salir) {
            try {
                opt = JOptionPane.showInputDialog(mensaje);
                switch (opt) {
                    case "a":
                        mostrarMaterias();
                        break;
                    case "b":
                        buscarMaterias();
                        break;
                    case "c":
                        agregarMateria();
                        break;
                    case "d":
                        salir = true;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Valor ingresado invalido\nSeleecione una opción del menu", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Hubo un problema con la obtencion de datos. Por favor intente de nuevo", "ERROR", JOptionPane.ERROR_MESSAGE);
                System.out.println(e.getMessage());
            }
        }
    }
}
