package sv.edu.udb.www.Complementario;

import sv.edu.udb.www.util.Conexion;

import javax.swing.*;
import java.sql.*;

import static sv.edu.udb.www.Complementario.Validaciones.validaNumero;

public class Materia {
    private static int cod_materia;
    private static String cod_materias;
    private static String nombre;
    private static String descripcion;

    private Connection conexion;
    private static ResultSet rs;
    private static Statement s;

    public Materia(){

    }

    public Materia(int cod_materia, String nombre, String descripcion, Connection conexion, ResultSet rs, Statement s) {
        this.cod_materia = cod_materia;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.conexion = conexion;
        this.rs = rs;
        this.s = s;
    }

    public static int getCod_materia() {
        return cod_materia;
    }

    public void setCod_materia(int cod_materia) {
        this.cod_materia = cod_materia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public static String getCod_materias() {
        return cod_materias;
    }

    public static void setCod_materias(String cod_materias) {
        Materia.cod_materias = cod_materias;
    }

    public Connection getConexion() {
        return conexion;
    }

    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }

    public ResultSet getRs() {
        return rs;
    }


    public void setRs(ResultSet rs) {
        this.rs = rs;
    }

    public Statement getS() {
        return s;
    }

    public void setS(Statement s) {
        this.s = s;
    }



    //METODO PARA MOSTRAR MATERIAS
    public static void mostrarMaterias() throws SQLException {
        Conexion con = new Conexion();
        String sql = "SELECT * from materia";
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();
        while (rs.next()){
            JOptionPane.showMessageDialog(null, "Codigo de Materia: " + rs.getString("Cod_materia") +
                    "\nNombre: " + rs.getString("Nombre")+
                    "\nDescripción: " + rs.getString("Descripcion"));
        };
    }

    //METODO PARA BUSCAR UNA MATERIA
    public static void buscarMaterias() throws SQLException {
        //Validacion del codigo de barra
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo de la materia");
        Long codigov = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codigov >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo de la materia");
                codigov = Long.parseLong(codigo);
            }
        } while (true);

        Conexion con = new Conexion();
        String sql = "SELECT * FROM materia WHERE Cod_materia = " + codigo;
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(null, "La materia no se encuentra en nuestra base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "MATERIA ENCONTRADA\n" +
                    "\nCodigo de Materia: " + rs.getString("Cod_Materia") +
                    "\nNombre: " + rs.getString("Nombre") +
                    "\nDescripción: " + rs.getString("Descripcion"));
        }
        con.cerrarConexion();
    }

    //METODO PARA AGREGAR MATERIAS
    public static void agregarMateria() throws SQLException{
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo de la materia. MAXIMO 10 DIGITOS");
        Long codv = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codv >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo de la materia. MAXIMO 10 DIGITOS");
                codv = Long.parseLong(codigo);
            }
        } while (true);
        cod_materia = Integer.parseInt(codigo);
        nombre = (JOptionPane.showInputDialog("Ingrese el nombre de la materia"));
        descripcion = (JOptionPane.showInputDialog("Imgrese una descripcion"));
        Conexion con = new Conexion();
        String sql = "insert into materia values(?,?,?)";
        PreparedStatement ps = con.getConexion().prepareStatement(sql);
        ps.setInt(1, cod_materia);
        ps.setString(2, nombre);
        ps.setString(3, descripcion);
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Se han insertado los datos");
    }

    //METODO PARA OBTENER LOS DATOS DE LA TABLA MATERIA
    public static void obtenerMaterias() throws SQLException {
        Conexion con = new Conexion();
        ResultSet rs = con.getS().executeQuery("select count(*) from materia");
        int tamanio = 0;
        while (rs.next()){
            tamanio = rs.getInt(1);
        }
        String[] options2 = new String[tamanio];
        int contador = 0;
        rs = con.getS().executeQuery("select * from materia");
        String texto = "";
        while (rs.next()){
            options2[contador] = rs.getString("Nombre");
            contador++;
        }
        cod_materias = (String) JOptionPane.showInputDialog(null, "Seleccione la materia para agregar", "Listado Materias", JOptionPane.QUESTION_MESSAGE, null, options2, options2[0]);
        rs = con.getS().executeQuery("select Cod_materia from materia where Nombre = '" + cod_materias + "'");
        while (rs.next()){
            cod_materia = rs.getInt(1);
        }
    }
}
