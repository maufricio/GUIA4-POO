package sv.edu.udb.www.Complementario;

public class Validaciones {
    public static boolean validaNumero(String codigo) {
        try {
            Long.parseLong(codigo);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
}
