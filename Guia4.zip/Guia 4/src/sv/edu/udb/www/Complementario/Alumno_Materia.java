package sv.edu.udb.www.Complementario;

import sv.edu.udb.www.util.Conexion;

import javax.swing.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import static sv.edu.udb.www.Complementario.Alumno.alumnoSeleccionado;
import static sv.edu.udb.www.Complementario.Materia.buscarMaterias;
import static sv.edu.udb.www.Complementario.Materia.obtenerMaterias;
import static sv.edu.udb.www.Complementario.Validaciones.validaNumero;

public class Alumno_Materia {
    private Alumno alumno = new Alumno();

    private ArrayList<Materia> materias = new ArrayList<Materia>();

    public Alumno_Materia(Alumno alumno, ArrayList<Materia> materias) {
        this.alumno = alumno;
        this.materias = materias;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public ArrayList<Materia> getMaterias() {
        return materias;
    }

    public void setMaterias(ArrayList<Materia> materias) {
        this.materias = materias;
    }

    //METODO PARA AGREGAR MATERIA A ALUMNO
    public static void agregarMateriaAlumno() throws SQLException {
        Alumno alumno = new Alumno();
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno. MAXIMO 10 DIGITOS");
        Long codv = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codv >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno. MAXIMO 10 DIGITOS");
                codv = Long.parseLong(codigo);
            }
        } while (true);
        alumno.setCod_alumno(Integer.parseInt(codigo));
        alumnoSeleccionado(alumno.getCod_alumno());
        obtenerMaterias();
        Conexion con = new Conexion();
        String sql = "insert into alumno_materia values(?,?)";
        PreparedStatement ps = con.getConexion().prepareStatement(sql);
        ps.setInt(1, alumno.getCod_alumno());
        ps.setInt(2, Materia.getCod_materia());
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "Se han insertado los datos");
    }

    public static void listarMateriasAlumno() throws SQLException{
        //Validacion del codigo de barra
        String codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno");
        Long codigov = Long.parseLong(codigo);
        do {
            if (validaNumero(codigo) == true && codigov >= 1) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "El dato ingresado no corresponde a un codigo\nIngrese de 1 a 10 numeros", "ERROR", JOptionPane.ERROR_MESSAGE);
                codigo = JOptionPane.showInputDialog("Ingrese el codigo del alumno");
                codigov = Long.parseLong(codigo);
            }
        } while (true);

        Conexion con = new Conexion();
        String sql = "SELECT alumno_materia.`Cod_alumno`, alumno_materia.`Cod_materia`, materia.`Nombre` FROM `alumno_materia`, `materia` WHERE Cod_alumno = " + codigo + " AND alumno_materia.Cod_materia = materia.Cod_materia";
        ResultSet rs;
        con.setRs(sql);
        rs = con.getRs();
        if (!rs.next()) {
            JOptionPane.showMessageDialog(null, "El alumno no se encuentra en nuestra base de datos", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {
            while (rs.next()) {
                JOptionPane.showMessageDialog(null, "MATERIAS ENCONTRADAS\n" +
                        "\nCodigo de Materia: " + rs.getString("Cod_materia") +
                        "\nNombre: " + rs.getString("Nombre"));
            }
        }
        con.cerrarConexion();
    }
}