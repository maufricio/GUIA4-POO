package sv.edu.udb.www.util;

import java.sql.*;

public class Conexion {
    private Connection conexion = null;
    private Statement s = null;
    private ResultSet rs = null;
    private String ingresoempleados = "";

    //Constructor
    public Conexion() throws SQLException{
        try{
            //Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Conexion a bdd
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/guia4", "root", "");
            //Sentencias sql
            s = conexion.createStatement();
            System.out.println("Conexion exitosa");
        }catch (ClassNotFoundException e1){
            System.out.println("ERROR: No encuentro el driver de la BD: " + e1.getMessage());
        }
    }

    public Connection getConexion() {
        return conexion;
    }

    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }

    public Statement getS() {
        return s;
    }

    public void setS(Statement s) {
        this.s = s;
    }

    public void setRs(ResultSet rs) {
        this.rs = rs;
    }

    public String getIngresoempleados() {
        return ingresoempleados;
    }

    public void setIngresoempleados(String ingresoempleados) {
        this.ingresoempleados = ingresoempleados;
    }

    //Metodo para obtener valores del resultset
    public ResultSet getRs(){
        return rs;
    }

    //Metodo fijar la tabla resultado de la pregunta sql
    public void setRs(String sql){
        try {
            this.rs = s.executeQuery(sql);
        }catch (SQLException e2){
            System.out.println("ERROR: Fallo en SQL: " + e2.getMessage());
        }
    }

    //Metodo recibe sql como parametro que sea un update, insert, delete
    public void setQuery(String sql) throws SQLException{
        this.s.executeUpdate(sql);
    }

    //Metodo que cierra conexion
    public void cerrarConexion() throws SQLException{
        conexion.close();
    }
}
