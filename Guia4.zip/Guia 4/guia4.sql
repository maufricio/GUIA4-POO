-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 23-02-2022 a las 04:32:32
-- Versión del servidor: 5.7.36
-- Versión de PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `guia4`
--
CREATE DATABASE IF NOT EXISTS `guia4` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `guia4`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

DROP TABLE IF EXISTS `alumno`;
CREATE TABLE IF NOT EXISTS `alumno` (
  `Cod_alumno` int(11) NOT NULL,
  `Nombre` varchar(80) NOT NULL,
  `Apellido` varchar(80) NOT NULL,
  `Edad` int(11) NOT NULL,
  `Direccion` varchar(100) NOT NULL,
  PRIMARY KEY (`Cod_alumno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`Cod_alumno`, `Nombre`, `Apellido`, `Edad`, `Direccion`) VALUES
(1, 'Victor Amilcar', 'Elías Peña', 23, 'Lourdes'),
(2, 'Mauricio Ernesto', 'Funes Cartagena', 45, 'Nicaragua'),
(3, 'Asasf', 'FD', 452, 'POr ahi vive');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno_materia`
--

DROP TABLE IF EXISTS `alumno_materia`;
CREATE TABLE IF NOT EXISTS `alumno_materia` (
  `Cod_alumno` int(11) NOT NULL,
  `Cod_materia` int(11) NOT NULL,
  KEY `Cod_alumno` (`Cod_alumno`),
  KEY `Cod_materia` (`Cod_materia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumno_materia`
--

INSERT INTO `alumno_materia` (`Cod_alumno`, `Cod_materia`) VALUES
(2, 2),
(2, 15),
(2, 15),
(1, 1),
(1, 1),
(1, 2),
(1, 3),
(1, 15),
(1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

DROP TABLE IF EXISTS `empleados`;
CREATE TABLE IF NOT EXISTS `empleados` (
  `Codigo` int(11) NOT NULL,
  `Nombre` varchar(25) DEFAULT NULL,
  `Apellidos` varchar(25) DEFAULT NULL,
  `Telefono` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`Codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`Codigo`, `Nombre`, `Apellidos`, `Telefono`) VALUES
(1, 'Roberto Mario', 'Rodrígez', '2589-8585'),
(2, 'Maria Gabriela', 'Carranza', '7895-7858'),
(3, 'José Fernando', 'Martinez', '2698-4576'),
(7, '', 'Torres', NULL),
(5, '', 'Torres', NULL),
(6, NULL, 'Rodriguez', NULL),
(10, NULL, 'Elias', NULL),
(11, NULL, 'Portillo', NULL),
(12, NULL, 'Cuadra', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

DROP TABLE IF EXISTS `materia`;
CREATE TABLE IF NOT EXISTS `materia` (
  `Cod_materia` int(11) NOT NULL,
  `Nombre` varchar(25) NOT NULL,
  `Descripcion` varchar(100) NOT NULL,
  PRIMARY KEY (`Cod_materia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`Cod_materia`, `Nombre`, `Descripcion`) VALUES
(1, 'DSS', 'Desarrollo de Sistemas Web'),
(2, 'POO', 'Programación Orientada a Objetos'),
(3, 'DGC', 'Gestores de contenidos'),
(15, 'AJsh', 'safddfg');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno_materia`
--
ALTER TABLE `alumno_materia`
  ADD CONSTRAINT `alumno_materia_ibfk_1` FOREIGN KEY (`Cod_materia`) REFERENCES `materia` (`Cod_materia`),
  ADD CONSTRAINT `alumno_materia_ibfk_2` FOREIGN KEY (`Cod_alumno`) REFERENCES `alumno` (`Cod_alumno`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
